<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
  <div class="collapse navbar-collapse" id="navbarCollapse">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item"><a class="nav-link" href="details.php">Home</a></li>
      <li class="nav-item"><a class="nav-link" href="safety_stock_frames.php">Safety Stock Frames</a></li>
      <li class="nav-item"><a class="nav-link" href="allpo.php">All PO</a></li>
      <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>            
    </ul>
  </div>
</nav>