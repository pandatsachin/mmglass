<?php

session_start();
$dbhost = "localhost";
$username = "root";
$password = "28sJFSZZozwn";
$db = "nowoptics";
$conn = new mysqli($dbhost, $username, $password, $db);
?>