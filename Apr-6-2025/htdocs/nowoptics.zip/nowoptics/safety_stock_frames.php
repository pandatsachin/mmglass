<?php
include("includes/config.php");
if(!isset($_SESSION['User'])) {
  header("Location:index.php");
}
//////////////////////////////
$qry = "select * from StantonSafetyStock";
$result = $conn->query($qry);
$tbl = '<table class="table table-striped">';
$tbl .= '<thead><tr><th scope="col">Description</th><th scope="col">Color Name</th><th scope="col">Size</th><th scope="col">Safety Stock</th><th scope="col">Safety Stock On Order</th></tr></thead>';
if($result->num_rows > 0) {
  while ($row = $result->fetch_object()) {
    $tbl .= '<tr><td>' . $row->Description . '</td><td>' . $row->ColorName . '</td><td>' . $row->Size . '</td><td>' . $row->SafetyStock . '</td><td>' . $row->SafetyStockOnOrder . '</td></tr>';
  }
}
$tbl .= '</table>';
include("includes/header.php");
?>
<link href="chosen/prism.css" rel="stylesheet">
<link href="chosen/chosen.css" rel="stylesheet">
<body style="align-items: baseline;">    
  <main role="main" class="container" style="margin-top: 75px; padding-bottom: 25px;">
    <?php
    include("includes/userlinks.php");
    ?>
    <div class="clearfix"></div>    
    <div class="row">
      <?php echo $tbl; ?>
    </div>    
  </main>
</body>
<?php
include("includes/footer.php");
?>