<?php
include("includes/config.php");
unset($_SESSION['User']);
header("Location:index.php");
?>