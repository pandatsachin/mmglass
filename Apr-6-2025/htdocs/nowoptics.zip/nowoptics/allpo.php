<?php
include("includes/config.php");
if(!isset($_SESSION['User'])) {
  header("Location:index.php");
}

//////////////////////////////
function array_to_csv_download($array, $filename = "export.csv", $delimiter = ",") {
  header('Content-Type: application/csv');
  header('Content-Disposition: attachment; filename="' . $filename . '";');
  $f = fopen('php://output', 'w');
  foreach($array as $line) {
	fputcsv($f, $line, $delimiter);
  }
}

$PONumber = '';
$InvoiceNumber = '';
$PO = '';
$tble_str = '';
$total_qty = 0;
$invoice_arr = array();
$csv_arr = array();
$csv_header_arr = array();
$csv_firstrow_arr = array();
$csv_total_arr = array();
//PO Search
$po_qry = "select PO from StantonStatus group by PO order by PO";
$poqry_result = $conn->query($po_qry);
while($poqry_row = $poqry_result->fetch_object()) {
  $PO = $poqry_row->PO;
  $csv_header_arr[] = 'PO Number';
  $csv_header_arr[] = 'MODEL NO';
  $csv_header_arr[] = 'TAG SKU NO';
  $csv_header_arr[] = 'QTY';
  $csv_header_arr[] = 'Now Optics ETA';
  $csv_header_arr[] = 'Chlogan ETA';
  $csv_header_arr[] = 'Destination DC';
  $tble_str .= '<div class="d-flex justify-content-center bg-primary" style="width: 100%;color: white;font-weight: bold;">Data for ' . $PO . '</div>';
  $tble_str .= '<table class="table table-striped">';
  $tbl_header = '<thead><tr><th scope="col">PO Number</th><th scope="col">MODEL NO</th>';
  $tbl_header .= '<th scope="col">TAG SKU NO</th><th scope="col">QTY</th>';
  $tbl_header .= '<th scope="col">Now Optics ETA</th><th scope="col">Chlogan ETA</th>';
  $tbl_header .= '<th scope="col">Destination DC</th>';
  $tbl_first_row = '<tr><td>Invoice Date</td><td></td><td></td><td></td><td></td><td></td><td></td>';
  $csv_firstrow_arr[] = 'Invoice Date';
  $csv_firstrow_arr[] = '';
  $csv_firstrow_arr[] = '';
  $csv_firstrow_arr[] = '';
  $csv_firstrow_arr[] = '';
  $csv_firstrow_arr[] = '';
  $csv_firstrow_arr[] = '';
  $PONumber_IN = array();
  $PONumber_IN_str = '';
  $poqry = "select PONumber from StantonStatus where PO='" . $PO . "' group by PONumber";
  $poresult = $conn->query($poqry);
  if($poresult->num_rows > 0) {
	while($porow = $poresult->fetch_object()) {
	  $PONumber_IN[] = "'" . $porow->PONumber . "'";
	}
  }
  $PONumber_str = implode(",", $PONumber_IN);
  $iqry = "select InvoiceNumber,InvoiceDate,InvoiceAmount,TrackingNumber from StantonSent where "
	  . "PONumber IN($PONumber_str) group by InvoiceNumber";
  $iresult = $conn->query($iqry);
  $cnt = 0;
  if($iresult->num_rows > 0) {
	while($irow = $iresult->fetch_object()) {
	  $tbl_header .= '<th scope="col">Invoice<br>' . $irow->InvoiceNumber . '<br>' . $irow->InvoiceAmount . '<br>' . $irow->TrackingNumber . '</th>';
	  $csv_header_arr[] = 'Invoice:' . $irow->InvoiceNumber . ':' . $irow->InvoiceAmount . ':' . $irow->TrackingNumber;
	  $tbl_first_row .= '<td>' . date('m/d/Y', strtotime($irow->InvoiceDate)) . '</td>';
	  $csv_firstrow_arr[] = date('m/d/Y', strtotime($irow->InvoiceDate));
	  $invoice_arr[$cnt] = 0;
	  $cnt++;
	}
  }
  $tbl_first_row .= '<td></td><td></td><td></td></tr>';
  $csv_firstrow_arr[] = '';
  $csv_firstrow_arr[] = '';
  $csv_firstrow_arr[] = '';
  $tbl_header .= '<th scope="col">Open</th><th scope="col">Note</th><th scope="col">Safety stock</th></tr></thead><tbody>';
  $csv_header_arr[] = 'Open';
  $csv_header_arr[] = 'Note';
  $csv_header_arr[] = 'Safety stock';
  $tble_str .= $tbl_header;
  $tble_str .= $tbl_first_row;
  $csv_arr[] = $csv_header_arr;
  $csv_arr[] = $csv_firstrow_arr;
  $poqry1 = "select PONumber from StantonStatus where PO='" . $PO . "' group by PONumber";
  $poresult1 = $conn->query($poqry1);
  if($poresult1->num_rows > 0) {
	while($porow1 = $poresult1->fetch_object()) {
	  $POPONumber = $porow1->PONumber;
	  $dqry = "select * from StantonStatus where PONumber='" . $POPONumber . "'";
	  $dresult = $conn->query($dqry);
	  $shipped_tot_arr = array();
	  if($dresult->num_rows > 0) {
		while($drow = $dresult->fetch_object()) {
		  $csv_data_arr = array();
		  $tble_str .= '<tr>';
		  $open = $drow->Ordered;
		  $total_qty += $drow->Ordered;
		  $DateExpected = empty($drow->DateExpected) ? '' : date('m/d/Y', strtotime($drow->DateExpected));
		  $DateRequired = empty($drow->DateRequired) ? '' : date('m/d/Y', strtotime($drow->DateRequired));
		  $tble_str .= '<td>' . $POPONumber . '</td>';
		  $tble_str .= '<td>' . $drow->StantonProductName . '</td>';
		  $tble_str .= '<td>' . $drow->StantonSku . '</td>';
		  $tble_str .= '<td>' . $drow->Ordered . '</td>';
		  $tble_str .= '<td>' . $DateExpected . '</td>';
		  $tble_str .= '<td>' . $DateRequired . '</td>';
		  $tble_str .= '<td></td>';
		  $csv_data_arr[] = $POPONumber;
		  $csv_data_arr[] = $drow->StantonProductName;
		  $csv_data_arr[] = $drow->StantonSku;
		  $csv_data_arr[] = $drow->Ordered;
		  $csv_data_arr[] = $DateExpected;
		  $csv_data_arr[] = $DateRequired;
		  $csv_data_arr[] = '';
		  $sqry = "select Shipped from StantonSent where PONumber='" . $POPONumber . "' and ItemID='" . $drow->ItemID . "' and "
			  . "SizeID='" . $drow->SizeID . "' and ColorID='" . $drow->ColorID . "'";
		  $sresult = $conn->query($sqry);
		  $tcnt = 0;
		  if($sresult->num_rows > 0) {
			while($srow = $sresult->fetch_object()) {
			  $tble_str .= '<td>' . $srow->Shipped . '</td>';
			  $csv_data_arr[] = $srow->Shipped;
			  $open = $open - $srow->Shipped;
			  $invoice_arr[$tcnt] = $invoice_arr[$tcnt] + $srow->Shipped;
			  $tcnt++;
			}
		  } else {
			for($m = 0; $m < $cnt; $m++) {
			  $tble_str .= '<td>0</td>';
			  $csv_data_arr[] = 0;
			  $invoice_arr[$m] = $invoice_arr[$m] + 0;
			}
		  }
		  $tble_str .= '<td>' . $open . '</td>';
		  $tble_str .= '<td>' . $drow->StantonNote . '</td>';
		  $tble_str .= '<td>' . $drow->SafetyStock . '</td>';
		  $csv_data_arr[] = $open;
		  $csv_data_arr[] = $drow->StantonNote;
		  $csv_data_arr[] = $drow->SafetyStock;
		  $tble_str .= '</tr>';
		  $csv_arr[] = $csv_data_arr;
		}
	  }
	}
  }
  $csv_total_arr[] = 'Total Qty';
  $csv_total_arr[] = '';
  $csv_total_arr[] = '';
  $csv_total_arr[] = $total_qty;
  $csv_total_arr[] = '';
  $csv_total_arr[] = '';
  $csv_total_arr[] = '';
  $tble_str .= '<tr><td>Total Qty</td><td></td><td></td><td>' . $total_qty . '</td><td></td><td></td><td></td>';
  for($i = 0; $i < $cnt; $i++) {
	$tble_str .= '<td>' . $invoice_arr[$i] . '</td>';
	$csv_total_arr[] = $invoice_arr[$i];
  }
  $tble_str .= '<td></td><td></td><td></td></tr>';
  $tble_str .= '</tbody></table>';
  $csv_total_arr[] = '';
  $csv_total_arr[] = '';
  $csv_total_arr[] = '';
  $csv_arr[] = $csv_total_arr;
}
//Create and download CSV
if(isset($_POST['download'])) {
  array_to_csv_download($csv_arr);
  exit;
}
////////////////////////////////////////////
include("includes/header.php");
$option_str = '<option value="">Search PONumber</option>';
$qry = "select * from StantonStatus group by PONumber order by PONumber";
$result = $conn->query($qry);
if($result->num_rows > 0) {
  while($row = $result->fetch_object()) {
	$selected = ($PONumber == $row->PONumber) ? 'selected' : '';
	$option_str .= '<option value="' . $row->PONumber . '" ' . $selected . '>' . $row->PONumber . '</option>';
  }
}
$option_istr = '<option value="">Search Invoice Number</option>';
$qry1 = "select InvoiceNumber from StantonSent group by InvoiceNumber order by InvoiceNumber";
$result1 = $conn->query($qry1);
if($result1->num_rows > 0) {
  while($row1 = $result1->fetch_object()) {
	$selected = ($InvoiceNumber == $row1->InvoiceNumber) ? 'selected' : '';
	$option_istr .= '<option value="' . $row1->InvoiceNumber . '" ' . $selected . '>' . $row1->InvoiceNumber . '</option>';
  }
}
//PO Drop down
$option_postr = '<option value="">Search PO</option>';
$qry2 = "select PO from StantonStatus group by PO order by PO";
$result2 = $conn->query($qry2);
if($result2->num_rows > 0) {
  while($row2 = $result2->fetch_object()) {
	$selected = ($PO == $row2->PO) ? 'selected' : '';
	$option_postr .= '<option value="' . $row2->PO . '" ' . $selected . '>' . $row2->PO . '</option>';
  }
}
?>
<link href="chosen/prism.css" rel="stylesheet">
<link href="chosen/chosen.css" rel="stylesheet">
<body style="align-items: baseline;">    
  <main role="main" class="container" style="margin-top: 75px; padding-bottom: 25px;">
	<?php
	include("includes/userlinks.php");
	?>
    <div class="clearfix"></div>    
	<?php
	//if(!empty($tble_str)) {
	  ?>
  	<!--<form name="download" method="post" action="" class="form-inline">
  	  <div class="row pt-3"><div class="col"><button type="submit" class="btn btn-primary" name="download">Download Sheet</button></div></div>
  	</form>-->
	  <?php
	//}
	?>
    <div class="row">
	  <?php echo $tble_str; ?>
    </div>    
  </main>
</body>
<?php
include("includes/footer.php");
?>