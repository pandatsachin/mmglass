<?php

include("includes/config.php");
//////////////////////////////////
$del_qry1 = "delete from StantonStatus";
$conn->query($del_qry1);
$del_qry2 = "delete from StantonSent";
$conn->query($del_qry2);
$del_qry3 = "delete from StantonSafetyStock";
$conn->query($del_qry3);
//Read and insert StantonStatus.csv
$i = 0;
if(($handle = fopen('csvfiles/StantonStatus.csv', "r")) !== FALSE) {
  while (($data = fgetcsv($handle, 0, ",")) !== FALSE) {
    if($i > 0) {
      $ID = trim($data[0]);
      $SkuID = trim($data[1]);
      $PONumber = trim($data[2]);
      $ItemID = trim($data[3]);
      $SizeID = trim($data[4]);
      $ColorID = trim($data[5]);
      $StantonProductName = trim($data[6]);
      $StantonSku = trim($data[7]);
      $Ordered = trim($data[8]);
      if(trim($data[9]) == '') {
        $Shipped = 0;
      } else {
        $Shipped = trim($data[9]);
      }
      $SafetyStock = trim($data[10]);
      $DateRequired = trim($data[11]);
      $DateExpected = trim($data[12]);
      $StantonNote = trim($data[13]);
      $Description = trim($data[14]);
      $ColorName = trim($data[15]);
      $Size = trim($data[16]);
      $PO = trim($data[17]);
      $qry = "INSERT INTO StantonStatus(ID,SkuID,PONumber,ItemID,SizeID,ColorID,StantonProductName,StantonSku,"
          . "Ordered,Shipped,SafetyStock,DateRequired,DateExpected,StantonNote,Description,ColorName,Size,PO) values ('" . $ID . "',"
          . "'" . $SkuID . "','" . $PONumber . "','" . $ItemID . "','" . $SizeID . "','" . $ColorID . "',"
          . "'" . $StantonProductName . "','" . $StantonSku . "','" . $Ordered . "','" . $Shipped . "',"
          . "'" . $SafetyStock . "','" . $DateRequired . "','" . $DateExpected . "','" . $StantonNote . "','" . $Description . "','" . $ColorName . "','" . $Size . "','" . $PO . "')";
      $conn->query($qry);
    }
    $i++;
  }
}
//Read and insert StantonSent.csv
$j = 0;
if(($handle = fopen('csvfiles/StantonSent.csv', "r")) !== FALSE) {
  while (($data = fgetcsv($handle, 0, ",")) !== FALSE) {
    if($j > 0) {
      $ItemID = trim($data[0]);
      $SizeID = trim($data[1]);
      $ColorID = trim($data[2]);
      $Shipped = trim($data[3]);
      $PONumber = trim($data[4]);
      $InvoiceNumber = trim($data[5]);
      $InvoiceDate = trim($data[6]);
      $InvoiceAmount = trim($data[7]);
      $TrackingNumber = trim($data[8]);
      $qry = "INSERT INTO StantonSent(ItemID,SizeID,ColorID,Shipped,PONumber,InvoiceNumber,InvoiceDate,InvoiceAmount,TrackingNumber) "
          . "values ('" . $ItemID . "','" . $SizeID . "','" . $ColorID . "','" . $Shipped . "'"
          . ",'" . $PONumber . "','" . $InvoiceNumber . "','" . $InvoiceDate . "','" . $InvoiceAmount . "','" . $TrackingNumber . "')";
      $conn->query($qry);
    }
    $j++;
  }
}
//Read and insert StantonSafetyStock.csv
$k = 0;
if(($handle = fopen('csvfiles/StantonSafetyStock.csv', "r")) !== FALSE) {
  while (($data = fgetcsv($handle, 0, ",")) !== FALSE) {
    if($k > 0) {
      $Description = trim($data[0]);
      $ColorName = trim($data[1]);
      $Size = trim($data[2]);
      $SafetyStock = trim($data[3]);
      $SafetyStockOnOrder = trim($data[4]);
      $SafetyStockOnOrder = empty($SafetyStockOnOrder) ? 0 : $SafetyStockOnOrder;
      $qry = "INSERT INTO StantonSafetyStock(Description,ColorName,Size,SafetyStock,SafetyStockOnOrder) "
          . "values ('" . $Description . "','" . $ColorName . "','" . $Size . "','" . $SafetyStock . "','" . $SafetyStockOnOrder . "')";
      $conn->query($qry);
    }
    $k++;
  }
}
echo "Done";
exit;
